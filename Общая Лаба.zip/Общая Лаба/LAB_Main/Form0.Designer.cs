﻿namespace лаба_1_главный_файл
{
    partial class Form0
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            button4 = new Button();
            label1 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            SuspendLayout();
            // 
            // button1
            // 
            button1.Location = new Point(50, 60);
            button1.Margin = new Padding(3, 2, 3, 2);
            button1.Name = "button1";
            button1.Size = new Size(127, 22);
            button1.TabIndex = 0;
            button1.Text = "Лабораторная 1";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.Location = new Point(50, 101);
            button2.Margin = new Padding(3, 2, 3, 2);
            button2.Name = "button2";
            button2.Size = new Size(127, 22);
            button2.TabIndex = 1;
            button2.Text = "Лабораторная 2";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button3
            // 
            button3.Location = new Point(50, 146);
            button3.Margin = new Padding(3, 2, 3, 2);
            button3.Name = "button3";
            button3.Size = new Size(127, 22);
            button3.TabIndex = 2;
            button3.Text = "Лабораторная 3";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // button4
            // 
            button4.Location = new Point(50, 189);
            button4.Margin = new Padding(3, 2, 3, 2);
            button4.Name = "button4";
            button4.Size = new Size(127, 22);
            button4.TabIndex = 3;
            button4.Text = "Лабораторная 4";
            button4.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(457, 83);
            label1.Name = "label1";
            label1.Size = new Size(155, 15);
            label1.TabIndex = 4;
            label1.Text = "Аникин Илья Максимович";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(457, 133);
            label3.Name = "label3";
            label3.Size = new Size(146, 15);
            label3.TabIndex = 6;
            label3.Text = "Дорошок Егор Иванович";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(457, 108);
            label4.Name = "label4";
            label4.Size = new Size(182, 15);
            label4.TabIndex = 7;
            label4.Text = "Тюньков Денис Александрович";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(457, 60);
            label5.Name = "label5";
            label5.Size = new Size(138, 15);
            label5.TabIndex = 8;
            label5.Text = "Студенты группы: 533-2";
            // 
            // Form0
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(700, 338);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label1);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Margin = new Padding(3, 2, 3, 2);
            Name = "Form0";
            Text = "Компьютерная графика";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button1;
        private Button button2;
        private Button button3;
        private Button button4;
        private Label label1;
        private Label label3;
        private Label label4;
        private Label label5;
    }
}
