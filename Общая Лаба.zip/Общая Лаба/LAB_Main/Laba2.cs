﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Задание_3;
using Lab1._6;
using WindowsFormsApp1;
using WindowsFormsApp2;
using Lab2.Individual;
using Задание_3_Лабораторная_2;
using WindowsFormsApplication1;
using LAB2;

namespace лаба_1_главный_файл
{
    public partial class Laba2 : Form
    {
        public Laba2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Osnova newOsnova = new Osnova();
            newOsnova.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Denis newDenis = new Denis();
            newDenis.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Egor newEgor = new Egor();
            newEgor.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Anikin newAnikin = new Anikin();
            newAnikin.Show();
        }
    }
}
