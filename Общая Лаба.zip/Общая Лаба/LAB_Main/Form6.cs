namespace Задание_3
{
    public partial class Form6 : Form
    {
        public Form6()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            double x1 = double.Parse(textBox1.Text);

            double x2 = double.Parse(textBox4.Text);

            double y1 = double.Parse(textBox3.Text);

            double y2 = double.Parse(textBox5.Text);

            double z1 = double.Parse(textBox2.Text);

            double z2 = double.Parse(textBox6.Text);

            double cx = y1 * z2 - z1 * y2;
            double cy = z1 * x2 - x1 * z2;
            double cz = x1 * y2 - y1 * x2;

            // Форматируем строку для отображения
            string message = $"Векторное произведение векторов: ({cx}, {cy}, {cz})";

            // Выводим результат в всплывающем окне
            MessageBox.Show(message, "Векторное произведение векторов", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
