using Вариант_3;

namespace лаба_1_главный_файл
{
    public partial class Form0 : Form
    {
        public Form0()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1 newForm1 = new Form1();
            newForm1.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Laba2 newLaba2 = new Laba2();
            newLaba2.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            LABA3 newLaba3 = new LABA3();
            newLaba3.Show();
        }
    }
}
