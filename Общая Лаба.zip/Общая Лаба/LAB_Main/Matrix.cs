﻿using System;

namespace WindowsFormsApp1
{
    public class Matrix
    {
        private double[,] data;
        private int rows;
        private int cols;

        // Конструктор для создания матрицы заданного размера
        public Matrix(int rows, int cols)
        {
            this.rows = rows;
            this.cols = cols;
            data = new double[rows, cols];
        }

        // Конструктор для создания матрицы из двумерного массива
        public Matrix(double[,] initialData)
        {
            this.rows = initialData.GetLength(0);
            this.cols = initialData.GetLength(1);
            data = new double[rows, cols];

            // Копируем данные из переданного массива
            for (int i = 0; i < rows; i++)
            {
                for (int j = 0; j < cols; j++)
                {
                    data[i, j] = 0;
                }
            }
        }

        // Свойства для доступа к размерам матрицы (только чтение)
        public int Rows { get { return rows; } }
        public int Cols { get { return cols; } }

        // Метод для установки значения элемента матрицы
        public void SetElement(int row, int col, double value)
        {
            if (row >= 0 && row < rows && col >= 0 && col < cols)
            {
                data[row, col] = value;
            }
            else
            {
                throw new IndexOutOfRangeException("Индекс находится вне границ матрицы.");
            }
        }

        // Метод для получения значения элемента матрицы
        public double GetElement(int row, int col)
        {
            if (row >= 0 && row < rows && col >= 0 && col < cols)
            {
                return data[row, col];
            }
            else
            {
                throw new IndexOutOfRangeException("Индекс находится вне границ матрицы.");
            }
        }

        // Метод для умножения матрицы на константу
        public Matrix MultiplyByConstant(double constant)
        {
            Matrix result = new Matrix(rows, cols);
            for (int i = 0; i < rows; i++)
            {
                for (int j = 0; j < cols; j++)
                {
                    result.SetElement(i, j, data[i, j] * constant);
                }
            }
            return result;
        }

        // Метод для вывода матрицы в консоль (для отладки)
        public void PrintMatrix()
        {
            for (int i = 0; i < rows; i++)
            {
                for (int j = 0; j < cols; j++)
                {
                    System.Console.Write(data[i, j] + " ");
                }
                System.Console.WriteLine();
            }
        }
    }
}