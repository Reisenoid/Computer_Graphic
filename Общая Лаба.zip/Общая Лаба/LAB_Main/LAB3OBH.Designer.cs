﻿namespace Lab3
{
    partial class LAB3OBH
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            panel1 = new Panel();
            splitContainer1 = new SplitContainer();
            pictureBox1 = new PictureBox();
            button15 = new Button();
            textBox3 = new TextBox();
            button14 = new Button();
            button13 = new Button();
            button12 = new Button();
            textBox2 = new TextBox();
            textBox1 = new TextBox();
            button11 = new Button();
            button10 = new Button();
            button9 = new Button();
            label1 = new Label();
            button8 = new Button();
            button1 = new Button();
            button7 = new Button();
            button2 = new Button();
            button6 = new Button();
            button3 = new Button();
            button5 = new Button();
            button4 = new Button();
            timer1 = new System.Windows.Forms.Timer(components);
            colorDialog1 = new ColorDialog();
            button16 = new Button();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)splitContainer1).BeginInit();
            splitContainer1.Panel1.SuspendLayout();
            splitContainer1.Panel2.SuspendLayout();
            splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.Controls.Add(splitContainer1);
            panel1.Dock = DockStyle.Fill;
            panel1.Location = new Point(0, 0);
            panel1.Margin = new Padding(3, 2, 3, 2);
            panel1.Name = "panel1";
            panel1.Size = new Size(941, 791);
            panel1.TabIndex = 0;
            // 
            // splitContainer1
            // 
            splitContainer1.Dock = DockStyle.Fill;
            splitContainer1.Location = new Point(0, 0);
            splitContainer1.Margin = new Padding(3, 2, 3, 2);
            splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            splitContainer1.Panel1.Controls.Add(pictureBox1);
            // 
            // splitContainer1.Panel2
            // 
            splitContainer1.Panel2.Controls.Add(button16);
            splitContainer1.Panel2.Controls.Add(button15);
            splitContainer1.Panel2.Controls.Add(textBox3);
            splitContainer1.Panel2.Controls.Add(button14);
            splitContainer1.Panel2.Controls.Add(button13);
            splitContainer1.Panel2.Controls.Add(button12);
            splitContainer1.Panel2.Controls.Add(textBox2);
            splitContainer1.Panel2.Controls.Add(textBox1);
            splitContainer1.Panel2.Controls.Add(button11);
            splitContainer1.Panel2.Controls.Add(button10);
            splitContainer1.Panel2.Controls.Add(button9);
            splitContainer1.Panel2.Controls.Add(label1);
            splitContainer1.Panel2.Controls.Add(button8);
            splitContainer1.Panel2.Controls.Add(button1);
            splitContainer1.Panel2.Controls.Add(button7);
            splitContainer1.Panel2.Controls.Add(button2);
            splitContainer1.Panel2.Controls.Add(button6);
            splitContainer1.Panel2.Controls.Add(button3);
            splitContainer1.Panel2.Controls.Add(button5);
            splitContainer1.Panel2.Controls.Add(button4);
            splitContainer1.Size = new Size(941, 791);
            splitContainer1.SplitterDistance = 661;
            splitContainer1.TabIndex = 0;
            // 
            // pictureBox1
            // 
            pictureBox1.Dock = DockStyle.Fill;
            pictureBox1.Location = new Point(0, 0);
            pictureBox1.Margin = new Padding(3, 2, 3, 2);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(661, 791);
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // button15
            // 
            button15.Location = new Point(3, 694);
            button15.Name = "button15";
            button15.Size = new Size(269, 35);
            button15.TabIndex = 18;
            button15.Text = "Подтвердить толщину линии";
            button15.UseVisualStyleBackColor = true;
            button15.Click += button15_Click;
            // 
            // textBox3
            // 
            textBox3.Location = new Point(3, 665);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(269, 23);
            textBox3.TabIndex = 17;
            // 
            // button14
            // 
            button14.Location = new Point(2, 624);
            button14.Name = "button14";
            button14.Size = new Size(270, 35);
            button14.TabIndex = 16;
            button14.Text = "Выбор цвета";
            button14.UseVisualStyleBackColor = true;
            button14.Click += button14_Click;
            // 
            // button13
            // 
            button13.Location = new Point(3, 450);
            button13.Name = "button13";
            button13.Size = new Size(270, 34);
            button13.TabIndex = 15;
            button13.Text = "Отражение X=Y";
            button13.UseVisualStyleBackColor = true;
            button13.Click += button13_Click;
            // 
            // button12
            // 
            button12.Location = new Point(3, 408);
            button12.Name = "button12";
            button12.Size = new Size(270, 36);
            button12.TabIndex = 14;
            button12.Text = "Отражение относительно X";
            button12.UseVisualStyleBackColor = true;
            button12.Click += button12_Click;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(2, 490);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(270, 23);
            textBox2.TabIndex = 13;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(3, 554);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(270, 23);
            textBox1.TabIndex = 12;
            textBox1.TextChanged += textBox1_TextChanged;
            // 
            // button11
            // 
            button11.Location = new Point(2, 583);
            button11.Name = "button11";
            button11.Size = new Size(270, 35);
            button11.TabIndex = 11;
            button11.Text = "Масштабирование";
            button11.UseVisualStyleBackColor = true;
            button11.Click += button11_Click;
            // 
            // button10
            // 
            button10.Location = new Point(3, 519);
            button10.Name = "button10";
            button10.Size = new Size(270, 29);
            button10.TabIndex = 10;
            button10.Text = "Поворот";
            button10.UseVisualStyleBackColor = true;
            button10.Click += button10_Click;
            // 
            // button9
            // 
            button9.Location = new Point(3, 364);
            button9.Name = "button9";
            button9.Size = new Size(270, 38);
            button9.TabIndex = 9;
            button9.Text = "Отражение относительно Y";
            button9.UseVisualStyleBackColor = true;
            button9.Click += button9_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 34.2F, FontStyle.Bold, GraphicsUnit.Point, 204);
            label1.Location = new Point(43, 106);
            label1.Name = "label1";
            label1.Size = new Size(181, 62);
            label1.TabIndex = 3;
            label1.Text = "СДВИГ";
            label1.Click += label1_Click;
            // 
            // button8
            // 
            button8.Location = new Point(3, 328);
            button8.Margin = new Padding(3, 2, 3, 2);
            button8.Name = "button8";
            button8.Size = new Size(270, 31);
            button8.TabIndex = 8;
            button8.Text = "Старт";
            button8.UseVisualStyleBackColor = true;
            button8.Click += button8_Click;
            // 
            // button1
            // 
            button1.Location = new Point(3, 2);
            button1.Margin = new Padding(3, 2, 3, 2);
            button1.Name = "button1";
            button1.Size = new Size(270, 29);
            button1.TabIndex = 0;
            button1.Text = "Нарисовать оси";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // button7
            // 
            button7.Location = new Point(3, 286);
            button7.Margin = new Padding(3, 2, 3, 2);
            button7.Name = "button7";
            button7.Size = new Size(270, 38);
            button7.TabIndex = 7;
            button7.Text = "По оси ОУ вверх";
            button7.UseVisualStyleBackColor = true;
            button7.Click += button7_Click;
            // 
            // button2
            // 
            button2.Location = new Point(3, 35);
            button2.Margin = new Padding(3, 2, 3, 2);
            button2.Name = "button2";
            button2.Size = new Size(270, 34);
            button2.TabIndex = 1;
            button2.Text = "Нарисовать фигуру";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button6
            // 
            button6.Location = new Point(3, 249);
            button6.Margin = new Padding(3, 2, 3, 2);
            button6.Name = "button6";
            button6.Size = new Size(270, 33);
            button6.TabIndex = 6;
            button6.Text = "По оси ОУ вниз";
            button6.UseVisualStyleBackColor = true;
            button6.Click += button6_Click;
            // 
            // button3
            // 
            button3.Location = new Point(3, 73);
            button3.Margin = new Padding(3, 2, 3, 2);
            button3.Name = "button3";
            button3.Size = new Size(270, 31);
            button3.TabIndex = 2;
            button3.Text = "Очистить";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // button5
            // 
            button5.Location = new Point(3, 209);
            button5.Margin = new Padding(3, 2, 3, 2);
            button5.Name = "button5";
            button5.Size = new Size(270, 36);
            button5.TabIndex = 5;
            button5.Text = "По оси ОХ влево";
            button5.UseVisualStyleBackColor = true;
            button5.Click += button5_Click;
            // 
            // button4
            // 
            button4.Location = new Point(3, 170);
            button4.Margin = new Padding(3, 2, 3, 2);
            button4.Name = "button4";
            button4.Size = new Size(270, 35);
            button4.TabIndex = 4;
            button4.Text = "По оси ОХ вправо";
            button4.UseVisualStyleBackColor = true;
            button4.Click += button4_Click;
            // 
            // timer1
            // 
            timer1.Enabled = true;
            timer1.Tick += timer1_Tick;
            // 
            // button16
            // 
            button16.Location = new Point(3, 735);
            button16.Name = "button16";
            button16.Size = new Size(269, 35);
            button16.TabIndex = 19;
            button16.Text = "Пунктирная линия";
            button16.UseVisualStyleBackColor = true;
            button16.Click += button16_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(941, 791);
            Controls.Add(panel1);
            Margin = new Padding(3, 2, 3, 2);
            Name = "Form1";
            Text = "Преобразования на плоскости";
            panel1.ResumeLayout(false);
            splitContainer1.Panel1.ResumeLayout(false);
            splitContainer1.Panel2.ResumeLayout(false);
            splitContainer1.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)splitContainer1).EndInit();
            splitContainer1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private SplitContainer splitContainer1;
        private PictureBox pictureBox1;
        private Button button1;
        private Button button2;
        private Button button3;
        private Label label1;
        private Button button4;
        private Button button5;
        private Button button6;
        private Button button7;
        private Button button8;
        private Button button9;
        private Button button10;
        private Button button11;
        private TextBox textBox1;
        private TextBox textBox2;
        private Button button12;
        private Button button13;
        public System.Windows.Forms.Timer timer1;
        private Button button14;
        private ColorDialog colorDialog1;
        private Button button15;
        private TextBox textBox3;
        private Button button16;
    }
}
