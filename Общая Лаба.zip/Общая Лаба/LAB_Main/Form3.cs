﻿using System;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form3 : Form
    {
        private Matrix myMatrix;

        public Form3()
        {
            InitializeComponent();
            // Начальная настройка DataGridView (можно настроить в дизайнере)
            dataGridView1.ColumnCount = 3;
            dataGridView1.RowCount = 3;
        }

        private void createMatrixButton_Click(object sender, EventArgs e)
        {
            // 1. Получите размеры матрицы из DataGridView
            int numRows = dataGridView1.RowCount;
            int numCols = dataGridView1.ColumnCount;

            if (numRows <= 0 || numCols <= 0)
            {
                MessageBox.Show("Пожалуйста, задайте положительное количество строк и столбцов в DataGridView.", "Ошибка");
                return;
            }

            // 2. Создайте матрицу
            myMatrix = new Matrix(numRows, numCols);

            // 3. Сброс DataGridView (чтобы увидеть только введенные значения, а не старые данные)
            dataGridView1.Rows.Clear();
            dataGridView1.Columns.Clear();
            dataGridView1.ColumnCount = numCols;
            dataGridView1.RowCount = numRows;

            //4. Заполните DataGridView значениями по умолчанию (например, нулями)
            for (int i = 0; i < numRows; i++)
            {
                for (int j = 0; j < numCols; j++)
                {
                    dataGridView1.Rows[i].Cells[j].Value = 0;
                }
            }
        }

        private void multiplyButton_Click(object sender, EventArgs e)
        {
            // 1. Убедитесь, что матрица была создана
            if (myMatrix == null)
            {
                MessageBox.Show("Сначала создайте матрицу!", "Ошибка");
                return;
            }

            // 2. Получите константу с использованием MessageBox с полем ввода
            string constantInput = ShowInputDialog("Введите константу для умножения:", "Умножение матрицы");

            double constant;
            if (!double.TryParse(constantInput, out constant))
            {
                MessageBox.Show("Пожалуйста, введите корректную константу (число).", "Ошибка");
                return;
            }

            // 3. Получите значения из DataGridView и заполните ими матрицу
            for (int i = 0; i < myMatrix.Rows; i++)
            {
                for (int j = 0; j < myMatrix.Cols; j++)
                {
                    double cellValue;
                    if (dataGridView1.Rows[i].Cells[j].Value != null && double.TryParse(dataGridView1.Rows[i].Cells[j].Value.ToString(), out cellValue))
                    {
                        myMatrix.SetElement(i, j, cellValue);
                    }
                    else
                    {
                        MessageBox.Show($"Некорректное значение в ячейке [{i},{j}]. Используется 0.", "Предупреждение");
                        myMatrix.SetElement(i, j, 0);
                    }
                }
            }

            // 4. Умножьте матрицу на константу
            Matrix multipliedMatrix = myMatrix.MultiplyByConstant(constant);

            // 5. Отобразите результат в DataGridView
            for (int i = 0; i < multipliedMatrix.Rows; i++)
            {
                for (int j = 0; j < multipliedMatrix.Cols; j++)
                {
                    dataGridView1.Rows[i].Cells[j].Value = multipliedMatrix.GetElement(i, j);
                }
            }
        }

        // Вспомогательный метод для отображения диалогового окна ввода
        private string ShowInputDialog(string prompt, string title)
        {
            Form promptForm = new Form()
            {
                Width = 400,
                Height = 150,
                FormBorderStyle = FormBorderStyle.FixedDialog,
                Text = title,
                StartPosition = FormStartPosition.CenterScreen
            };
            Label textLabel = new Label() { Left = 50, Top = 20, Text = prompt, Width = 300 };
            TextBox textBox = new TextBox() { Left = 50, Top = 50, Width = 300 };
            Button confirmation = new Button() { Text = "OK", Left = 200, Width = 100, Top = 80, DialogResult = DialogResult.OK };
            Button cancel = new Button() { Text = "Cancel", Left = 50, Width = 100, Top = 80, DialogResult = DialogResult.Cancel };
            confirmation.Click += (sender, e) => { promptForm.Close(); };
            cancel.Click += (sender, e) => { promptForm.Close(); };
            promptForm.Controls.Add(textBox);
            promptForm.Controls.Add(confirmation);
            promptForm.Controls.Add(cancel);
            promptForm.Controls.Add(textLabel);
            promptForm.AcceptButton = confirmation;
            promptForm.CancelButton = cancel;

            return promptForm.ShowDialog() == DialogResult.OK ? textBox.Text : "";
        }
    }
}