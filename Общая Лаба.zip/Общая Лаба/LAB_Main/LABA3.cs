﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Lab3;
using Lab3.Ind;

namespace лаба_1_главный_файл
{
    public partial class LABA3 : Form
    {
        public LABA3()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            LAB3OBH newLAB3OBH = new LAB3OBH();
            newLAB3OBH.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Triangles newTriangles = new Triangles();
            newTriangles.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Drosh newDrosh = new Drosh();
            newDrosh.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
             
        }
    }
}
