namespace Задание_3
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            double x1 = double.Parse(textBox1.Text);

            double x2 = double.Parse(textBox4.Text);

            double y1 = double.Parse(textBox3.Text);

            double y2 = double.Parse(textBox5.Text);

            double z1 = double.Parse(textBox2.Text);

            double z2 = double.Parse(textBox6.Text);

            double result = (x1*x2)+(y1*y2)+(z1*z2);

            // Форматируем строку для отображения
            string message = $"Скалярное произведение векторов: {result}";

            // Выводим результат в всплывающем окне
            MessageBox.Show(message, "Скалярное произведение векторов", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
