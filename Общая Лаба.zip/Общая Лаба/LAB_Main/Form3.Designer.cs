﻿namespace WindowsFormsApp1
{
    partial class Form3
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            dataGridView1 = new DataGridView();
            createMatrixButton = new Button();
            multiplyButton = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(37, 384);
            dataGridView1.Margin = new Padding(2);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 82;
            dataGridView1.RowTemplate.Height = 33;
            dataGridView1.Size = new Size(447, 240);
            dataGridView1.TabIndex = 0;
            // 
            // createMatrixButton
            // 
            createMatrixButton.Location = new Point(71, 186);
            createMatrixButton.Margin = new Padding(2);
            createMatrixButton.Name = "createMatrixButton";
            createMatrixButton.Size = new Size(217, 35);
            createMatrixButton.TabIndex = 1;
            createMatrixButton.Text = "Создать матрицу";
            createMatrixButton.UseVisualStyleBackColor = true;
            createMatrixButton.Click += createMatrixButton_Click;
            // 
            // multiplyButton
            // 
            multiplyButton.Location = new Point(334, 186);
            multiplyButton.Margin = new Padding(2);
            multiplyButton.Name = "multiplyButton";
            multiplyButton.Size = new Size(198, 35);
            multiplyButton.TabIndex = 2;
            multiplyButton.Text = "Умножить";
            multiplyButton.UseVisualStyleBackColor = true;
            multiplyButton.Click += multiplyButton_Click;
            // 
            // Form3
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(608, 679);
            Controls.Add(multiplyButton);
            Controls.Add(createMatrixButton);
            Controls.Add(dataGridView1);
            Margin = new Padding(2);
            Name = "Form3";
            StartPosition = FormStartPosition.CenterScreen;
            Tag = "";
            Text = "Умножение матрицы на константу";
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button createMatrixButton;
        private System.Windows.Forms.Button multiplyButton;
    }
}

