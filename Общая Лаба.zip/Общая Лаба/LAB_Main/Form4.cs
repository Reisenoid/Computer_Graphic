﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form4 : Form
    {
        // Объявляем элементы управления для координат векторов и результатов
        private TextBox textBoxX1, textBoxY1, textBoxZ1, textBoxX2, textBoxY2, textBoxZ2;
        private Button calculateButton, clearButton;
        private Label resultLabel;

        public Form4()
        {
            InitializeComponent();
            InitializeUI(); // Создаем элементы управления динамически
        }

        private void InitializeUI()
        {
            // Настройка элементов управления
            textBoxX1 = new TextBox() { Location = new Point(10, 10), Width = 50 };
            textBoxY1 = new TextBox() { Location = new Point(70, 10), Width = 50 };
            textBoxZ1 = new TextBox() { Location = new Point(130, 10), Width = 50 };
            textBoxX2 = new TextBox() { Location = new Point(10, 40), Width = 50 };
            textBoxY2 = new TextBox() { Location = new Point(70, 40), Width = 50 };
            textBoxZ2 = new TextBox() { Location = new Point(130, 40), Width = 50 };
            calculateButton = new Button() { Location = new Point(10, 70), Text = "Вычислить" };
            clearButton = new Button() { Location = new Point(90, 70), Text = "Очистить" };
            resultLabel = new Label() { Location = new Point(10, 100), Width = 300, Height = 150, BorderStyle = BorderStyle.FixedSingle };

            // Подписываемся на события кнопок
            calculateButton.Click += calculateButton_Click;
            clearButton.Click += clearButton_Click;

            // Добавляем элементы управления на форму
            Controls.Add(textBoxX1);
            Controls.Add(textBoxY1);
            Controls.Add(textBoxZ1);
            Controls.Add(textBoxX2);
            Controls.Add(textBoxY2);
            Controls.Add(textBoxZ2);
            Controls.Add(calculateButton);
            Controls.Add(clearButton);
            Controls.Add(resultLabel);

            // Настройка формы
            ClientSize = new Size(320, 260);
            Text = "Модуль вектора";
        }


        private void calculateButton_Click(object sender, EventArgs e)
        {
            try
            {
                // 1. Получение данных из текстовых полей
                double x1 = Convert.ToDouble(textBoxX1.Text);
                double y1 = Convert.ToDouble(textBoxY1.Text);
                double z1 = Convert.ToDouble(textBoxZ1.Text);

                double x2 = Convert.ToDouble(textBoxX2.Text);
                double y2 = Convert.ToDouble(textBoxY2.Text);
                double z2 = Convert.ToDouble(textBoxZ2.Text);

                // 2. Создание объектов Vector с использованием конструктора
                Vector vector1 = new Vector(x1, y1, z1);
                Vector vector2 = new Vector(x2, y2, z2);

                // 3. Выполнение операций
                Vector sum = vector1.Add(vector2);
                Vector difference = vector1.Subtract(vector2);
                double dotProduct = vector1.DotProduct(vector2);
                Vector crossProduct = vector1.CrossProduct(vector2);
                double length1 = vector1.Length();
                double length2 = vector2.Length();

                // 4. Отображение результатов
                resultLabel.Text = $"Сумма: {sum}\n" +
                                   $"Разность: {difference}\n" +
                                   $"Скалярное произведение: {dotProduct}\n" +
                                   $"Векторное произведение: {crossProduct}\n" +
                                   $"Длина первого вектора: {length1}\n" +
                                   $"Длина второго вектора: {length2}";
                resultLabel.ForeColor = Color.Black; // Изменить цвет текста
            }
            catch (FormatException)
            {
                resultLabel.Text = "Ошибка: Неверный формат ввода. Введите числа.";
                resultLabel.ForeColor = Color.Red; // Изменить цвет текста на красный при ошибке
            }
            catch (Exception ex)
            {
                resultLabel.Text = "Произошла ошибка: " + ex.Message;
                resultLabel.ForeColor = Color.Red; // Изменить цвет текста на красный при ошибке
            }
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            // Очистка текстовых полей
            textBoxX1.Clear();
            textBoxY1.Clear();
            textBoxZ1.Clear();
            textBoxX2.Clear();
            textBoxY2.Clear();
            textBoxZ2.Clear();
            resultLabel.Text = ""; // Очистка поля с результатами
            resultLabel.ForeColor = Color.Black; // Сброс цвета текста
        }
    }
}