﻿using System;

namespace WindowsFormsApp2
{
    public class Vector
    {
        public double X { get; set; }
        public double Y { get; set; }
        public double Z { get; set; }

        // Конструктор по умолчанию (нулевой вектор)
        public Vector() : this(0, 0, 0) { }

        // Конструктор с заданными координатами
        public Vector(double x, double y, double z)
        {
            X = x;
            Y = y;
            Z = z;
        }

        // Конструктор копирования
        public Vector(Vector other) : this(other.X, other.Y, other.Z) { }

        // Метод для вычисления длины вектора
        public double Length()
        {
            return Math.Sqrt(X * X + Y * Y + Z * Z);
        }

        // Метод для сложения векторов
        public Vector Add(Vector other)
        {
            return new Vector(X + other.X, Y + other.Y, Z + other.Z);
        }

        // Метод для вычитания векторов
        public Vector Subtract(Vector other)
        {
            return new Vector(X - other.X, Y - other.Y, Z - other.Z);
        }

        // Метод для умножения вектора на скаляр
        public Vector Multiply(double scalar)
        {
            return new Vector(X * scalar, Y * scalar, Z * scalar);
        }

        // Метод для вычисления скалярного произведения
        public double DotProduct(Vector other)
        {
            return X * other.X + Y * other.Y + Z * other.Z;
        }

        // Метод для вычисления векторного произведения
        public Vector CrossProduct(Vector other)
        {
            return new Vector(Y * other.Z - Z * other.Y, Z * other.X - X * other.Z, X * other.Y - Y * other.X);
        }

        // Переопределение метода ToString для удобного вывода
        public override string ToString()
        {
            return $"({X}, {Y}, {Z})";
        }
    }
}